I added 2 .txt files. One has the concatenated output of the 3 reducers, the other one sorts it (using the first column)

combined.txt = combined output (part-r-00000 + part-r-00001 + part-r-00002)
sorted.txt = sorted output (sorts combined.txt by key|first|only column since each row is just one big string)
