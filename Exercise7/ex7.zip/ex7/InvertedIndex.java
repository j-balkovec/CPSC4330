package stubs;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.conf.Configuration;


public class InvertedIndex {

 public static void main(String[] args) throws Exception {

    if (args.length != 2) {
      System.out.printf("Usage: InvertedIndex <input dir> <output dir>\n");
      System.exit(-1);
    }

    Configuration conf = new Configuration();
    Job job = Job.getInstance(conf, "Inverted Index");
    job.setJarByClass(InvertedIndex.class);
  

   
    /*
     * We are using a KeyValueText file as the input file.
     * Therefore, we must call setInputFormatClass.
     * There is no need to call setOutputFormatClass, because the
     * application uses a text file for output.
     */
     job.setInputFormatClass(KeyValueTextInputFormat.class);
    

     /*
      * TODO implement
      */
    
    
    boolean success = job.waitForCompletion(true);
    System.exit(success ? 0 : 1);
  }
}
